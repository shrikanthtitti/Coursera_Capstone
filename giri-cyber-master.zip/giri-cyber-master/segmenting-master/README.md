# Coursera_Capstone
Coursera Capstone Project
First part of Assignment to cluster and map neighborhoods in Toronto.
xx
PART 1:
The final result is a table containing "PostalCode",  "Borough" and "Neighbourhood" of Toronto
xx
xx
PART 2:
starts in cell 38 :  Here, two more columns are added for "Latitude" and "Longitude"
xx
xx
PART 3:
starts in cell 43 :  Here the Foursquare API is used to generate venues for the neighhorhoods that contain the word "Toronto"
and maps of clusters are created.
